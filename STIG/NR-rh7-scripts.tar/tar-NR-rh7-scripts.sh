#!/bin/bash

tar cf NR-rh7-scripts.tar ./*.sh

